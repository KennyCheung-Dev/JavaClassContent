module javacodes {
}
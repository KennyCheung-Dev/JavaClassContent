package maincodes;

public class BaseSystem {

	public static void main(String[] args) {
		System.out.println(Integer.toString(7, 2));
	}

}

package maincodes;

public class FibonacciSequence {

	public static void main(String[] args) {
		int n = 0;
		int back1 = 0;
		int back2 = 0;
		while (n <= 10) {
			if (n <= 1) {
				System.out.println(n);
				back2 = back1;
				back1 = n;
			} else {
				n = back2 + back1;
				System.out.println(n);
				back2 = back1;
				back1 = n;
			}
			n += 1;
		}
	}

}

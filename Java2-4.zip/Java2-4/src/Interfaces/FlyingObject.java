package Interfaces;

public interface FlyingObject {
	void Escalate();
	void Lower();
}

package maincodes;

public class HomeworkAnswer {

	public static void main(String[] args) {
		//Q
		//In-Class Exercise: 
				//Make a method that takes in an array of int as input, then print 2 lines: 
				//Line 1: The Sum is : { }
				//Line 2: The lowest number is : { }
				//Challenge: See if you an finish with just 1 loop
				int[] data = {5, 68, 243, 3, 747, 1, 2, 50};
				ProcessData(data);

	}

	//Answer
	public static void ProcessData(int[] input) {
		int sum = 0; 
		int lowest = input[0];
		//Loop through all the numbers with foreach loop
		for(int i : input) {
			//Compare the current number with the lowest number field
			if (i < lowest) {
				//assign it to the lowest number field if it is lower
				lowest = i;
			}
			//Add the number to sum field
			sum += i;
		}
		//Output the final sum and lowest 
		System.out.println("The Sum is : " + sum);
		System.out.println("The lowest number is : " + lowest);
	}
	
}


package Interface;

public interface Movable {
	public void move();
}

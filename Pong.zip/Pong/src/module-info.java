module Pong {
	requires java.desktop;
}
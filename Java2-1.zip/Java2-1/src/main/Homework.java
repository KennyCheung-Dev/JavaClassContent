package main;

public class Homework {

	/* Homework:
	 * Multiple-Choice P.110
	 * # 1, 2, 3
	 * 
	 * Race Car Question:
	 * Let CarA and CarB running to the same direction
	 * CarA started at 0km, running at 250km/h
	 * CarB started at 150km, running at 230km/h
	 * 
	 * Find out how many hours it takes for CarA to catch up to CarB
	 * 
	 * Code Specification:
	 * Car class will have two constructor, one takes in only speed, one takes in speed and startDistance
	 * Check every 0.1 hours, or more frequently if you like
	 * 
	 * The rest are your freedom
	 * Code will also be rated by structure, 
	 * how clean have you modulate your functionality and works with future changes
	 * - Some question to guide you: 
	 * What if I have more than 2 cars?
	 * What if I want a report for their distance traveled each 0.1 hours
	 * what if I want 1 decimal place displayed for the hours, and 4 decimal places displayed for distance travelled
	 * (Hint: make helper function for these)
	 */
	
	public static void main(String[] args) {}

}

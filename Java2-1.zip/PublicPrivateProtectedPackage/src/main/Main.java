package main;

import characters.*;
import enemies.*;

public class Main {
	private static Player1 jimmy = new Player1();
	public static void main(String[] args) {
		jimmy.ReportHp();
		jimmy.TakeDamage(30);
		
		
	}

}

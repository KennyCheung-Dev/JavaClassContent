package enemies;

public class Skeleton {
	
}

package Animals;

public class Bird extends Animals {
	private double flySpeed;
	
	public Bird(String name, int age, double d) {
		super(name, age);
		this.flySpeed = d;
	}

	public void Fly() {
		System.out.println("Flap..Flap..Flap..Flap.. at " + flySpeed + " km/h");
	}
}

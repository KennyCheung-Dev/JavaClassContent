package Animals;

public class Dolphin extends Animals {
	double swimSpeed;
	
	public Dolphin(String name, int age, double swimSpeed) {
		super(name, age);
		this.swimSpeed = swimSpeed;
	}
	
	public void Swim() {
		System.out.println("Sploosh..Sploosh..Sploosh..Sploosh.. at " + swimSpeed + " km/h");
	}
}

package maincodes;

public class HomeworkAns_Triangle {
	public static void main(String[] args) {
		Triangle(20);
	}
	
	public static void Triangle(int n) {
		int currentNum = 0;
		for (int i = 1; i < (n + 1); i++) {
			for (int j = 0; j < i; j++) {
				System.out.print(currentNum + " ");
				 currentNum += 1;
			}
			System.out.println();
		}
	}
}

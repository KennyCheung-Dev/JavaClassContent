package maincodes;

public class FibonacciSequence {

	public static void main(String[] args) {
		System.out.println("Final Answer: " + Fib(10));
		System.out.println("Recursion Answer: " + FibRcr(10));
		
	}
	
	//Explain with Tree Diagram
	
	public static int Fib(int n) {
		int counter = 0;
		//Start with the first number
		int i = 1;
		int back1 = 0;
		int back2 = 0;
		//End 1 before n, Loop through n times from 0, even though number starts from 1
		while (counter < n) {
			if (i <= 1) {
				System.out.println(i);
				back2 = back1;
				back1 = i;
			} else {
				i = back2 + back1;
				System.out.println(i);
				back2 = back1;
				back1 = i;
			}
			i += 1;
			counter += 1;
		}
		return i - 1;
	}
	
	public static int FibRcr(int n) {
		if (n == 0) {
			return 0;
		} else if (n == 1) {
			return 1;
		} else {
			return FibRcr(n-1) + FibRcr(n-2);
		}
	}

}
